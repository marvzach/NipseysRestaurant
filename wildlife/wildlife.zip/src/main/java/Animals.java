public abstract class Animals {
  public String name;
  public int id;


  public String getName() {
    return name;
  }

  public int getId() {
    return id;
  }
}